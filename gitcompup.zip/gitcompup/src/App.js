import React, { Component } from 'react';
import MenuBar from './Components/MenuBar';
import {Switch, Route, BrowserRouter} from "react-router-dom";


import NewsMainWindow from './Components/NewsMainWindow';




class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
        currentUser: null
    };
  }
  
  render() {
    return (
      <BrowserRouter>
      <div style ={{backgraund:"green",  marginRight:5, marginTop:10, width: "100%",  height: "100%", display:"flex"}}>
      <MenuBar/>
            <Switch>                    
                     
                        <Route path="/NewsMainWindow" component={NewsMainWindow} />                            
             </Switch>
      </div>
       </BrowserRouter>
    );
  }
}

export default App;