import React from 'react';
import axios from 'axios';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import Paper from '@material-ui/core/Paper';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Check from '@material-ui/icons/Check';
import Close from '@material-ui/icons/Close';
import Button from '@material-ui/core/Button';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import iconId1 from "../icons/categoryIcons/iconId1.png";
import iconId2 from "../icons/categoryIcons/iconId2.png";
import iconId3 from "../icons/categoryIcons/iconId3.png";
import iconId4 from "../icons/categoryIcons/iconId4.png";
import iconId5 from "../icons/categoryIcons/iconId5.png";
import iconId6 from "../icons/categoryIcons/iconId6.png";
import iconId7 from "../icons/categoryIcons/iconId7.png";
import iconId8 from "../icons/categoryIcons/iconId8.png";
import infon from "../icons/common/infon.png";
import arrown from "../icons/common/arrown.png";

function biggestToSmallest(a, b) {
  return new Date(b.publishDate) - new Date(a.publishDate);
} 

class NewsMainWindow extends React.Component {

  constructor() {
    super();
    this.state = {
    newsList: [],
    open: false,
    expandedNews: true,
    openNews: false,
    sort: false,
    moreNews: 3, 

    };
  }

  handleChangeNews = (panel) => (event, isExpanded) => {
    this.setState( {expandedNews: isExpanded ? panel : false});};

  handleFormatNumberToDate = (date) => {
      var d = new Date(date*1000);
      var datestring = ("0" + d.getDate()).slice(-2) + "." + ("0"+(d.getMonth()+1)).slice(-2) + "." + d.getFullYear();
      return datestring;
  };

  handleClickShowMore = () => {
    var more = this.state.moreNews + 3;
    this.setState({ moreNews: more });
};

  componentDidMount() {
        //BackDataService.getAllNews()
        axios.get(`http://130.193.44.96:8080/fmh/news`)
       // axios.get(`https://avdeevaelena.github.io/json/newsUpdate2.json`)
            .then(res => {
              console.log('!!!!!!!!!!!', res.data)
              const newsList = res.data;
              this.setState({ newsList });
            }) 
  
    } 

render() {    
const sorted = this.state.newsList.sort(biggestToSmallest);
var size = this.state.newsList.size;       
let more = this.state.moreNews;
  //const showNewsAccordionList = this.state.newsList.map(s => {
const showNewsAccordionList = sorted.slice(size,more).map(s => {
   let publishEnabledIcon;
      let icon;
      switch (s.newsCategoryId) {
        case 1: icon = <img  alt={"test"} src={iconId1}/>; break;
        case 2: icon = <img  alt={"test"} src={iconId2}/>; break;
        case 3: icon = <img  alt={"test"} src={iconId3}/>; break;
        case 4: icon = <img  alt={"test"} src={iconId4}/>; break;
        case 5: icon = <img  alt={"test"} src={iconId5}/>; break;
        case 6: icon = <img  alt={"test"} src={iconId6}/>; break;
        case 7: icon = <img  alt={"test"} src={iconId7}/>; break; 
        case 8: icon = <img  alt={"test"} src={iconId8}/>; break;  
        default: break; 
        }
      let publicDate = this.handleFormatNumberToDate(s.publishDate); 
      let createDate = this.handleFormatNumberToDate(s.createDate); 
    
      if (s.publishEnabled == 'false') {
        publishEnabledIcon =<Typography><Close/>  НЕ РАЗМЕЩЕНА</Typography>
      } else {
        publishEnabledIcon =<Typography><Check/>  РАЗМЕЩЕНА</Typography>;
      }
              return (  
          <Accordion expanded={this.expandedNews }
          style={{border: 'green', boxShadow: '0px 2px 0px 0px #38c6d7' }}
          onChange={this.handleChangeNews(s.createDate)}>

          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            style={{
                    marginBottom: '2px',
                    border: 'green',
                    boxShadow: '0px 2px 0px 0px #38c6d7',
                    display: 'inlineFlex'
          }}
            aria-controls="panel2bh-content">
            <ListItemIcon>{icon} </ListItemIcon>  
            <Typography > {s.title} </Typography>
            <Typography style={{fontSize: 'theme.typography.pxToRem(15)',
            float: 'right',
            position: 'absolute',
            right: '50px',
            flexShrink: 0, color: 'grey'}}> {publicDate} </Typography>
          </AccordionSummary>

          <AccordionDetails style={{ display:'block'}}>

<Box item boxShadow={1} xs={3} 
style={{ display:'flex', width: '100%'}} >
          <Typography
          style={{ float: 'left', width: '30%'}}
          >Дата публикации: </Typography >
          <Typography
          style={{ float: 'right', width: '70%'}}
          > {publicDate} </Typography > 
  </Box>

  <Box item boxShadow={1} xs={3}
  style={{ display:'flex', width: '100%'}}>
             <Typography style={{ float: 'left', width: '30%'}}>
             Дата создания:  </Typography>
             <Typography
          style={{ float: 'right', width: '70%'}}
          >{createDate}
           </Typography>
  </Box>
  <Box item boxShadow={1} xs={3}
  style={{ display:'flex', width: '100%'}}>
             <Typography style={{ float: 'left', width: '30%'}}>
           Автор:
           </Typography>
           <Typography style={{ float: 'right', width: '70%'}}>
           {s.creatorId}
           </Typography>
  </Box> 
  <Box item boxShadow={1} xs={3}
  style={{ display:'flex', boxShadow: 'none', width: '100%', justifyContent: 'space-between', paddingTop: '10px'}}>
  <Typography style={{ float: 'left'}}>
            {publishEnabledIcon}
  </Typography>         
 </Box>      
            <div style={{ float: 'left'}}> 
            <Typography>
            {s.description}
            </Typography>
            </div>
          </AccordionDetails>
      </Accordion>
      )
   }
   
   ); 

   return (
        <div style={{marginRight:2, width:'100%' }}>
              <Paper style={{marginTop:60 }} elevation={1}>
        <Typography variant="h5" component="h3"
        style={{ paddingBottom:8, paddingLeft:8, backgroundColor: '#E3E3E3', textAlign: 'left' }} >
          Новости  
        <Button  color="primary" 
          style={{float: 'right'}}> 
        <img  alt={"test"} src={arrown}/>
        </Button> 
        <Button  color="primary" 
          style={{float: 'right'}}> 
        <img  alt={"test"} src={infon}/>
        </Button> 
        </Typography> 
      <div>
         {showNewsAccordionList}
    </div>
    <Button  color="primary" 
   style={{width:'100%', color:'#01A19F', textAlign: 'center'}}
   onClick={this.handleClickShowMore}>ПОКАЗАТЬ ЕЩЁ</Button>    
        </Paper>   
          </div>      
   )
      }
}

export default NewsMainWindow;