import http from "../http-common";


class BackDataService {

  getAllNews() {
    return http.get("/news");
  }


  updateNews (idNews, title,newsCategoryId, text, longFormatDatePublic ){
    console.log("updateNews idNews=", idNews);
    console.log("updateNews =", title);
    console.log("updateNews =", newsCategoryId);
    console.log("updateNews", text);
    console.log("updateNews", longFormatDatePublic);
    var body = {
      id: 'value',
      title: 'title',
      newsCategoryId: 'dnewsCategoryId'
  };
    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: body
    };
    console.log("NEW =", newsCategoryId);
    return fetch(``, body)
     // .then(handleResponse)
      .then(user => {
  
        return user;
      });     
  }

  createNews (title,eventId, text, show, date){
    console.log("CREATE NEWS POst SERVICE idNews=", title);
    console.log("CREATE NEWS POst SERVICE idNews=", eventId);
    console.log("CREATE NEWS POst SERVICE idNews=", text);
    console.log("CREATE NEWS POst SERVICE idNews=", show);
    console.log("CREATE NEWS POst SERVICE idNews=", date);
    var body = {
      id: 'value',
      title: 'title',
      newsCategoryId: 'dnewsCategoryId'
  };
    const requestOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: body
    };
    return fetch(``, body)
     // .then(handleResponse)
      .then(user => {
  
        return user;
      });     
  }

}

export default new BackDataService();